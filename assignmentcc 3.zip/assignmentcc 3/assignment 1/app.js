const express = require('express');
const fs = require('fs').promises;  // Use the promise-based version of fs module
const path = require('path');

const app = express();
const port = 3000;

// Middleware to parse JSON in request body
app.use(express.json());

// Serve static files from the 'public' directory
app.use(express.static('public'));

// Paths to necessary directories and files
const publicDir = path.join(__dirname, 'public');
const devicesFile = path.join(__dirname, 'devices.json');
const logsFile = path.join(__dirname, 'logs.txt');

// Initialization function to ensure necessary files and directories exist
async function initialize() {
  await ensureDirectoryExists(publicDir);
  await ensureFileExists(devicesFile, '[]');
  await ensureFileExists(logsFile, '');
}

// Task 2: Device Registration
app.post('/register', async (req, res) => {
  const { deviceId, deviceType } = req.body;

  if (!deviceId || !deviceType) {
    return res.status(400).json({ error: 'Both deviceId and deviceType are required.' });
  }

  const existingDevices = await loadDevices();

  if (existingDevices.some(device => device.deviceId === deviceId)) {
    return res.status(409).json({ error: 'Device already registered.' });
  }

  existingDevices.push({ deviceId, deviceType });
  await saveDevices(existingDevices);
  await logData(`Device registered - Device ID: ${deviceId}, Device Type: ${deviceType}`);
  res.status(201).json({ message: 'Device registered successfully.' });
});

// Task 3: Displaying Devices
app.get('/show', async (req, res) => {
  const devices = await loadDevices();
  res.json(devices);
});

// Task 4: Receiving Device Data
app.post('/data', async (req, res) => {
  const { deviceId, data } = req.body;

  if (!deviceId || !data) {
    return res.status(400).json({ error: 'Both deviceId and data are required.' });
  }

  await logData(`Data received from Device ID ${deviceId} - ${data}`);
  res.json({ message: 'Data received successfully.' });
});

// Task 5: Sending Commands to Devices
app.post('/command', async (req, res) => {
  const { deviceId, command } = req.body;

  if (!deviceId || !command) {
    return res.status(400).json({ error: 'Both deviceId and command are required.' });
  }

  await logData(`Command sent to Device ID ${deviceId} - ${command}`);
  res.json({ message: 'Command sent successfully.' });
});

// Task 6: Logging
async function logData(message) {
  const timestamp = new Date().toISOString();
  await fs.appendFile(logsFile, `${timestamp}: ${message}\n`);
}

// Load existing devices from devices.json
async function loadDevices() {
  try {
    const data = await fs.readFile(devicesFile, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    console.error(`Error reading devices.json: ${error.message}`);
    return [];
  }
}

// Save devices to devices.json
async function saveDevices(devices) {
  try {
    await fs.writeFile(devicesFile, JSON.stringify(devices, null, 2), 'utf8');
  } catch (error) {
    console.error(`Error writing to devices.json: ${error.message}`);
  }
}

// Ensure the existence of a directory
async function ensureDirectoryExists(directory) {
  try {
    await fs.mkdir(directory, { recursive: true });
  } catch (error) {
    console.error(`Error creating directory ${directory}: ${error.message}`);
  }
}

// Ensure the existence of a file with default content
async function ensureFileExists(file, defaultContent) {
  try {
    await fs.writeFile(file, defaultContent, { flag: 'wx' }); // 'wx' - write, fail if the file exists
  } catch (error) {
    if (error.code !== 'EEXIST') {
      console.error(`Error creating file ${file}: ${error.message}`);
    }
  }
}

// Start the server after initialization
initialize().then(() => {
  app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
  });
}).catch(error => {
  console.error('Failed to initialize:', error);
});