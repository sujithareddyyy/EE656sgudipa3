Node.js Product Management API
This project is a simple product management API built using Node.js and MySQL. It allows users to add, retrieve, update, and delete product information from a MySQL database.

Prerequisites
Before you begin, ensure you have the following installed:

Node.js
MySQL Server
Installation
Clone the repository to your local machine:
bash
Copy code
git clone https://github.com/yourusername/yourrepository.git
Navigate into the project directory:
bash
Copy code
cd yourrepository
Install the required npm packages:
Copy code
npm install
Database Setup
Log in to your MySQL server:
css
Copy code
mysql -u root -p
Create a new database:
sql
Copy code
CREATE DATABASE your_database;
Select your database:
Copy code
USE your_database;
Create a new table for products:
sql
Copy code
CREATE TABLE products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL
);
Configuration
Edit the database connection settings in your application code:

javascript
Copy code
const db = mysql.createConnection({
    host: 'localhost',
    user: 'your_username',
    password: 'your_password',
    database: 'your_database'
});
Running the Application
Start the server:

Copy code
node index.js
The server will run on http://localhost:3000.

API Endpoints
POST /products: Add a new product
GET /products: Retrieve all products
GET /products/:id: Retrieve a single product by ID
PUT /products/:id: Update a product by ID
DELETE /products/:id: Delete a product by ID
Testing
You can test the API endpoints using Postman or any other API testing tool by sending requests to http://localhost:3000/products.