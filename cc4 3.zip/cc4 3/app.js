const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const app = express();
const port = 3000;

app.use(bodyParser.json());

function readProducts() {
    const data = fs.readFileSync('products.json', { encoding: 'utf8', flag: 'r' });
    return JSON.parse(data).products;
}

function writeProducts(products) {
    fs.writeFileSync('products.json', JSON.stringify({ products }, null, 2), { encoding: 'utf8' });
}

// POST endpoint to create a new product
app.post('/products', (req, res) => {
    const products = readProducts();
    const { name, price, quantity } = req.body;
    const id = products.length + 1;
    const product = { id, name, price, quantity };
    products.push(product);
    writeProducts(products);
    res.status(201).send(product);
});

// GET endpoint to retrieve all products
app.get('/products', (req, res) => {
    const products = readProducts();
    res.status(200).send(products);
});

// GET endpoint to retrieve a single product
app.get('/products/:id', (req, res) => {
    const products = readProducts();
    const product = products.find(p => p.id === parseInt(req.params.id));
    if (!product) {
        return res.status(404).send('Product not found');
    }
    res.status(200).send(product);
});

// PUT endpoint to update a product
app.put('/products/:id', (req, res) => {
    const products = readProducts();
    const product = products.find(p => p.id === parseInt(req.params.id));
    if (!product) {
        return res.status(404).send('Product not found');
    }
    const { name, price, quantity } = req.body;
    product.name = name;
    product.price = price;
    product.quantity = quantity;
    writeProducts(products);
    res.status(200).send(product);
});

// DELETE endpoint to delete a product
app.delete('/products/:id', (req, res) => {
    let products = readProducts();
    const index = products.findIndex(p => p.id === parseInt(req.params.id));
    if (index === -1) {
        return res.status(404).send('Product not found');
    }
    products.splice(index, 1);
    writeProducts(products);
    res.status(204).send();
});

// Start the server
app.listen(port, () => {
    console.log(`Server running on port ${port}`);
});
