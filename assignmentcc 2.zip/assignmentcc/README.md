# cloud-computing
Here is the README file with instructions on how to set up and run the application:

# IoT Device Management

This Node.js application using Express.js is designed for managing IoT devices. It supports registering new devices, displaying registered devices, receiving data from devices, and sending commands to devices. The system also maintains logs of all activities and persists device information.

## Table of Contents

- [Setup](#setup)
- [Usage](#usage)
- [Endpoints](#endpoints)
- [Logging](#logging)
- [Bonus (Optional)](#bonus-optional)
- [Web Interface](#web-interface)

## Setup

### Prerequisites

- Node.js installed on your machine. You can download it from [https://nodejs.org/](https://nodejs.org/).

### Installation

1. Clone the repository:

   ```bash
   git clone https://github.com/your-username/iot-device-management.git
   
Navigate to the project directory:
cd iot-device-management

Install dependencies:
npm install

Usage:
Run the server: node app.js

The server will be running at http://localhost:3000.

Access the web interface:

Open your web browser and navigate to http://localhost:3000. Use the provided HTML file (public/index.html) to interact with the API endpoints.

Endpoints
Device Registration
Endpoint: POST /register
Parameters:
deviceId (required): Unique identifier for the device.
deviceType (required): Type or category of the device.

Displaying Devices
Endpoint: GET /show
Displays a list of all registered devices.

Receiving Device Data
Endpoint: POST /data
Parameters:
deviceId (required): ID of the device sending data.
data (required): Data sent by the device.

Sending Commands to Devices
Endpoint: POST /command
Parameters:
deviceId (required): ID of the device receiving the command.
command (required): Command to be sent to the device.

Logging
All activities (registrations, received data, commands) are logged with timestamps in the logs.txt file.
Bonus (Optional)
Implement a function loadDevices to load existing devices from devices.json into memory on application startup.
